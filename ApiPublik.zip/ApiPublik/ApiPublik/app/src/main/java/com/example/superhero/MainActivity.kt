//Nama               : Nurul Fitriani Zahra
//Nim                : 10122066
//Kelas              : Pemrograman Android 4
//tanggal pengerjaan : 10 Agustus 2025


package com.example.superhero

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.superhero.databinding.ActivityMainBinding
import com.example.superhero.model.SuperheroResponse
import com.example.superhero.network.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    companion object {
        // Ganti ID superhero di sini
        private const val HERO_ID = "370"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        findHero()
    }

    private fun findHero() {
        val apiService = ApiConfig.getApiService()

        val apiToken = BuildConfig.SUPERHERO_API_TOKEN

        val client = apiService.getSuperhero(apiToken, HERO_ID)

        client.enqueue(object : Callback<SuperheroResponse> {
            override fun onResponse(
                call: Call<SuperheroResponse>,
                response: Response<SuperheroResponse>
            ) {
                if (response.isSuccessful) {
                    val hero = response.body()
                    if (hero != null) {
                        setData(hero)
                    }
                } else {
                    val errorMessage = response.message()
                    Toast.makeText(this@MainActivity, getString(R.string.error_failed_to_load, errorMessage), Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<SuperheroResponse>, t: Throwable) {
                val errorMessage = t.message
                Toast.makeText(this@MainActivity, getString(R.string.error_connection_failed, errorMessage), Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun setData(hero: SuperheroResponse) {
        val notAvailable = getString(R.string.data_not_available)

        binding.tvHeroName.text = hero.name ?: notAvailable

        Glide.with(this)
            .load(hero.image?.url)
            .into(binding.ivHeroImage)

        // Perbaikan: Tampilkan Powerstats dengan ProgressBar
        hero.powerstats?.let { stats ->
            // Intelligence
            val intelligence = stats.intelligence?.toIntOrNull() ?: 0
            binding.pbIntelligence.progress = intelligence
            binding.tvValueIntelligence.text = intelligence.toString()

            // Strength
            val strength = stats.strength?.toIntOrNull() ?: 0
            binding.pbStrength.progress = strength
            binding.tvValueStrength.text = strength.toString()

            // Speed
            val speed = stats.speed?.toIntOrNull() ?: 0
            binding.pbSpeed.progress = speed
            binding.tvValueSpeed.text = speed.toString()

            // Durability
            val durability = stats.durability?.toIntOrNull() ?: 0
            binding.pbDurability.progress = durability
            binding.tvValueDurability.text = durability.toString()

            // Power
            val power = stats.power?.toIntOrNull() ?: 0
            binding.pbPower.progress = power
            binding.tvValuePower.text = power.toString()

            // Combat
            val combat = stats.combat?.toIntOrNull() ?: 0
            binding.pbCombat.progress = combat
            binding.tvValueCombat.text = combat.toString()
        }

        // Tampilkan Biography
        hero.biography?.let { bio ->
            binding.tvValueFullName.text = bio.fullName ?: notAvailable
            binding.tvValueAlterEgos.text = bio.alterEgos ?: notAvailable
            binding.tvValueAliases.text = bio.aliases?.joinToString(", ") ?: notAvailable
            binding.tvValuePlaceOfBirth.text = bio.placeOfBirth ?: notAvailable
            binding.tvValueFirstAppearance.text = bio.firstAppearance ?: notAvailable
            binding.tvValuePublisher.text = bio.publisher ?: notAvailable
            binding.tvValueAlignment.text = bio.alignment ?: notAvailable
        }

        // Tampilkan Appearance
        hero.appearance?.let { app ->
            binding.tvValueGender.text = app.gender ?: notAvailable
            binding.tvValueRace.text = app.race ?: notAvailable
            binding.tvValueHeight.text = app.height?.joinToString(" / ") ?: notAvailable
            binding.tvValueWeight.text = app.weight?.joinToString(" / ") ?: notAvailable
            binding.tvValueEyeColor.text = app.eyeColor ?: notAvailable
            binding.tvValueHairColor.text = app.hairColor ?: notAvailable
        }

        // Tampilkan Work
        hero.work?.let { work ->
            binding.tvValueOccupation.text = work.occupation ?: notAvailable
            binding.tvValueBase.text = work.base ?: notAvailable
        }

        // Tampilkan Connections
        hero.connections?.let { conn ->
            binding.tvValueGroupAffiliation.text = conn.groupAffiliation ?: notAvailable
            binding.tvValueRelatives.text = conn.relatives ?: notAvailable
        }
    }
}