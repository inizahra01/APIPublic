package com.example.superhero.model

import com.google.gson.annotations.SerializedName

data class SuperheroResponse(
    @SerializedName("id")
    val id: String? = null,
    @SerializedName("name")
    val name: String? = null,
    @SerializedName("powerstats")
    val powerstats: Powerstats?,
    @SerializedName("biography")
    val biography: Biography?,
    @SerializedName("appearance")
    val appearance: Appearance?,
    @SerializedName("work")
    val work: Work?,
    @SerializedName("connections")
    val connections: Connections?,
    @SerializedName("image")
    val image: Image?
)

data class Powerstats(
    @SerializedName("intelligence")
    val intelligence: String? = null,
    @SerializedName("strength")
    val strength: String? = null,
    @SerializedName("speed")
    val speed: String? = null,
    @SerializedName("durability")
    val durability: String? = null,
    @SerializedName("power")
    val power: String? = null,
    @SerializedName("combat")
    val combat: String? = null
)

data class Biography(
    @SerializedName("full-name")
    val fullName: String? = null,
    @SerializedName("alter-egos")
    val alterEgos: String? = null,
    @SerializedName("aliases")
    val aliases: List<String>? = null,
    @SerializedName("place-of-birth")
    val placeOfBirth: String? = null,
    @SerializedName("first-appearance")
    val firstAppearance: String? = null,
    @SerializedName("publisher")
    val publisher: String? = null,
    @SerializedName("alignment")
    val alignment: String? = null
)

data class Appearance(
    @SerializedName("gender")
    val gender: String? = null,
    @SerializedName("race")
    val race: String? = null,
    @SerializedName("height")
    val height: List<String>? = null,
    @SerializedName("weight")
    val weight: List<String>? = null,
    @SerializedName("eye-color")
    val eyeColor: String? = null,
    @SerializedName("hair-color")
    val hairColor: String? = null
)

data class Work(
    @SerializedName("occupation")
    val occupation: String? = null,
    @SerializedName("base")
    val base: String? = null
)

data class Connections(
    @SerializedName("group-affiliation")
    val groupAffiliation: String? = null,
    @SerializedName("relatives")
    val relatives: String? = null
)

data class Image(
    @SerializedName("url")
    val url: String? = null
)