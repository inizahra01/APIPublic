package com.example.superhero.network

import com.example.superhero.model.SuperheroResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("api/{token}/{id}")
    fun getSuperhero(
        @Path("token") token: String,
        @Path("id") id: String
    ): Call<SuperheroResponse>
}